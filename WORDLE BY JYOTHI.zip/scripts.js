var total = 6
var count = 0
var row = 1
var exp_word = "ANGLE";
var lett_2 = "";
var lett_3 = "";
var lett_4 = "";
var lett_5 = "";
var letters = /^[A-Za-z]+$/;
var act_word = ""

$(document).ready(function() {
   
    exp_word = exp_word.toUpperCase();
    var exp_word_arry = [exp_word.charAt(0).toUpperCase(), exp_word.charAt(1).toUpperCase(),
        exp_word.charAt(2).toUpperCase(), exp_word.charAt(3).toUpperCase(), exp_word.charAt(4).toUpperCase()
    ];
    $("#trl_cnt").val("6/6");
   

    $(".button").click(function() {

        lett_1 = $("#cell_" + row + "1").val().toUpperCase();
        lett_2 = $("#cell_" + row + "2").val().toUpperCase();
        lett_3 = $("#cell_" + row + "3").val().toUpperCase();
        lett_4 = $("#cell_" + row + "4").val().toUpperCase();
        lett_5 = $("#cell_" + row + "5").val().toUpperCase();

        
            act_word_array = [lett_1, lett_2, lett_3, lett_4, lett_5];
            act_word = lett_1 + lett_2 + lett_3 + lett_4 + lett_5;
            $("#trials").text("Attempts Remaining: "+String( 6-row) + "/6");
            $(".row"+row).prop('disabled', true);
            if (act_word == exp_word) {
                for (var i = 0; i < 5; i++) {
                   var cell = String(i + 1);
                    $("#cell_" + row + cell).css("background-color", "green");
                    $("#cell_" + row + cell).css("color", "white");
                }
                $("#alerts").text("You Won The Game");
                
            } else {
                for (var i = 0; i < 5; i++) {
                    if (act_word_array[i] == exp_word_arry[i]) {
                       var cell = String(i + 1);
                        $("#cell_" + row + cell).css("background-color", "green");
                        $("#cell_" + row + cell).css("color", "white");
                    } else {
                        var isFound = false;
                        for (var j = 0; j < 5; j++) {
                            if (act_word_array[i] == exp_word_arry[j]) {
                                isFound = true;
                            }
                        }
                        if (isFound) {
                            var cell = String(i + 1);
                            $("#cell_" + row + cell).css("background-color", "olive");
                            $("#cell_" + row + cell).css("color", "white");
                        } else {
                            var cell = String(i + 1);
                            $("#cell_" + row + cell).css("background-color", "RED");
                            $("#cell_" + row + cell).css("color", "white");
                        }

                    }


                }
                row = row + 1;
                
            
        
			}
    });
});
